/**
 * 
 */
package de.htwg.net;

import java.io.IOException;
import java.io.OutputStream;

/**
 * @author Ellen Wieland
 *
 */
public class SwitchableOutputStream extends OutputStream {
	
	private OutputStream outputStream;
	
	public SwitchableOutputStream(OutputStream outputStream) {
		// TODO
		this.outputStream = outputStream;
	}
	
	public void switchOutputStream(OutputStream outputStream) throws IOException {
		// TODO
		this.outputStream.flush();
		this.outputStream = outputStream;
	}

	
	// delegate work to internal output stream
	
	/* (non-Javadoc)
	 * @see java.io.OutputStream#close()
	 */
	@Override
	public void close() throws IOException {
		outputStream.close();
	}

	/* (non-Javadoc)
	 * @see java.io.OutputStream#flush()
	 */
	@Override
	public void flush() throws IOException {
		outputStream.flush();
	}

	/* (non-Javadoc)
	 * @see java.io.OutputStream#write(byte[], int, int)
	 */
	@Override
	public void write(byte[] b, int off, int len) throws IOException {
		outputStream.write(b, off, len);
	}

	/* (non-Javadoc)
	 * @see java.io.OutputStream#write(byte[])
	 */
	@Override
	public void write(byte[] b) throws IOException {
		outputStream.write(b);
	}

	/* (non-Javadoc)
	 * @see java.io.OutputStream#write(int)
	 */
	@Override
	public void write(int b) throws IOException {		
		outputStream.write(b);
	}
	
}
