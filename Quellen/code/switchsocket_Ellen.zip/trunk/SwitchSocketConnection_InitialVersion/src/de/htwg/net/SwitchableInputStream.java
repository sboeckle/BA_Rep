/**
 * 
 */
package de.htwg.net;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * @author Ellen Wieland
 *
 */
public class SwitchableInputStream extends InputStream {
	
	private InputStream inputStream;
	private ArrayList<InputStream> newInputStreams;
	
	public SwitchableInputStream(InputStream inputStream) {
		// TODO
		this.inputStream = inputStream;
		this.newInputStreams = new ArrayList<InputStream>();
	}

	public void switchInputStream(InputStream inputStream) {
		// TODO
		this.newInputStreams.add(inputStream);
	}
	
	
	// delegate work to internal input stream

	/* (non-Javadoc)
	 * @see java.io.InputStream#available()
	 */
	@Override
	public int available() throws IOException {
		return inputStream.available();
	}

	/* (non-Javadoc)
	 * @see java.io.InputStream#close()
	 */
	@Override
	public void close() throws IOException {
		inputStream.close();
	}

	/* (non-Javadoc)
	 * @see java.io.InputStream#mark(int)
	 */
	@Override
	public synchronized void mark(int readlimit) {
		inputStream.mark(readlimit);
	}

	/* (non-Javadoc)
	 * @see java.io.InputStream#markSupported()
	 */
	@Override
	public boolean markSupported() {
		return inputStream.markSupported();
	}

	/* (non-Javadoc)
	 * @see java.io.InputStream#read(byte[], int, int)
	 */
	@Override
	public int read(byte[] b, int off, int len) throws IOException {
		int data = 0;
		if ((data = inputStream.read(b, off, len)) == -1) {
			// test if EOF was caused because other side wants to switch connection
			if (!newInputStreams.isEmpty()) {
				inputStream = newInputStreams.remove(0);
				return this.read(b, off, len);
			// not caused by switch connection
			} else {
				return -1;
			}
		} else {
			return data;
		}
	}

	/* (non-Javadoc)
	 * @see java.io.InputStream#read(byte[])
	 */
	@Override
	public int read(byte[] b) throws IOException {		
		int data = 0;
		if ((data = inputStream.read(b)) == -1) {
			// test if EOF was caused because other side wants to switch connection
			if (!newInputStreams.isEmpty()) {
				inputStream = newInputStreams.remove(0);
				return this.read(b);
			// not caused by switch connection
			} else {
				return -1;
			}
		} else {
			return data;
		}
	}
	
	/* (non-Javadoc)
	 * @see java.io.InputStream#read()
	 */
	@Override
	public int read() throws IOException {
		int data = 0;
		if ((data = inputStream.read()) == -1) {
			// test if EOF was caused because other side wants to switch connection
			if (!newInputStreams.isEmpty()) {
				inputStream = newInputStreams.remove(0);
				return this.read();
			// not caused by switch connection
			} else {
				return -1;
			}
		} else {
			return data;
		}
	}

	/* (non-Javadoc)
	 * @see java.io.InputStream#reset()
	 */
	@Override
	public synchronized void reset() throws IOException {
		inputStream.reset();
	}

	/* (non-Javadoc)
	 * @see java.io.InputStream#skip(long)
	 */
	@Override
	public long skip(long n) throws IOException {
		return inputStream.skip(n);
	}
}
