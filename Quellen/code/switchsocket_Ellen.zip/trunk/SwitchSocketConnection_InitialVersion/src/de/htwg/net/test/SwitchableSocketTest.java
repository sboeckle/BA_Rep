package de.htwg.net.test;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SwitchableSocketTest {
	
	private TCPByteSender sender;
	private Thread controlInstanceThread;
	
	private static final String testMessage = "Test Message = Current Time: ";
	
	@Before
	public void setUp() {
		sender = new TCPByteSender();
		ControlInstance controlInstance = new ControlInstance(sender);
		
		controlInstanceThread = new Thread(controlInstance);
		controlInstanceThread.start();
	}
	
	@Test
	public void testCorrectDataExchange() {
		long startTime = System.currentTimeMillis();
		for(int i = 0; i < 10000; i++) {
			try {
				String message = testMessage + System.currentTimeMillis();
				String answer = sender.sendMessage(message);
				assertEquals(message, answer);
			} catch (Exception e) {
				fail("The following Exception occured: " + e.getMessage());
			}
		}
		long endTime = System.currentTimeMillis();
		System.out.println("The test took: " + (endTime - startTime) + " milliseconds.");
	}
	
	
	
	@After
	public void tearDown() {
		controlInstanceThread.interrupt();
		try {
			sender.getSocket().close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("END");
	}
	

}
