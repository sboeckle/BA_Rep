/**
 * 
 */
package de.htwg.net.test;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import de.htwg.net.SwitchableSocket;

/**
 * @author Ellen Wieland
 *
 */
public class TCPByteReceiver implements Runnable {

	private SwitchableSocket switchableSocket;
	private OutputStream out;
	private InputStream in;
	
		
	public TCPByteReceiver(Socket socket) {
		try {
			switchableSocket = new SwitchableSocket(socket);
			out = switchableSocket.getOutputStream();
			in = switchableSocket.getInputStream();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	public void run() {		
		try {
			byte[] buffer = new byte[32];
			int recvMsgSize;
			while ((recvMsgSize = in.read(buffer)) != -1) {				
				
				String message = new String(buffer).trim();
				System.out.println(message.substring(0, recvMsgSize));
				out.write(buffer, 0, recvMsgSize);
				out.flush();
			}
			System.out.println("GOT -1");
			System.exit(0);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {		
		try {
			ServerSocket serverSocket = new ServerSocket(8205);			
			System.out.println("TCPServer waiting for messages..");
			
			TCPByteReceiver receiver = new TCPByteReceiver(serverSocket.accept());
			Thread thread = new Thread(receiver);
			thread.start();
			
			while (true) {
				// switch socket connection when a new client connects
				Socket newSocket = serverSocket.accept();
				System.out.println("SWITCH");
				receiver.switchableSocket.switchSocket(newSocket);
			}			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
