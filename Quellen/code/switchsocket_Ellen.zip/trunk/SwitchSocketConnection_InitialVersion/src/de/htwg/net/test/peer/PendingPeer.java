package de.htwg.net.test.peer;

import java.net.Socket;


public class PendingPeer {
	
	
	private Socket socket;
	
	private String peerName;
	private String address;
	private int port = 0;
	
	public PendingPeer(Socket socket, String peerName, String address, int port) {
		this.socket = socket;
		this.peerName = peerName;
		this.address = address;
		this.port = port;
	}

	/**
	 * @return the socket
	 */
	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}
	/**
	 * @return the peerName
	 */
	public String getPeerName() {
		return peerName;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @return the port
	 */
	public int getPort() {
		return port;
	}		
	
}
