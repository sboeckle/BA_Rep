/**
 * 
 */
package de.htwg.net.test.peer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * @author Ellen
 *
 */
public class UserDialog extends Thread {
	
	private String peerName;
	private String address;
	private int port = 0;
	
    private ActivePeerManager activePeerManager = null;
    private PendingPeerManager pendingPeerManager = null;

	private BufferedReader reader;
	
	
	/**
	 * @param myInfo
	 */
	public UserDialog(String peerName, String address, int port) {
		if (address ==  null) {
			// TODO: error string
			throw new IllegalArgumentException("");
		}
		this.peerName = peerName;
		this.address = address;
		this.port = port;
        reader = new BufferedReader(new InputStreamReader(System.in));
        start();
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Peer name: " + peerName);
		System.out.println("Listening At: " + address + ":" + port);
		try {
			while (true) {
				processCommand(reader.readLine());
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		 
	}


	/**
	 * @param line
	 */
	private void processCommand(String line) {
		line = line.trim();		
		if (line.length() == 0) {
			return;
		} else {
			if (activePeerManager == null) // builder pattern
				showError("No Peer Manager!");
			else {
				activePeerManager.sendToAll(line);
				showMessage(peerName + ": " + line);
			}
		}
	}

	/**
	 * @param activePeerManager
	 */
	public void setActivePeerManager(ActivePeerManager activePeerManager) {
		if (this.activePeerManager == null) {
			this.activePeerManager = activePeerManager;
		}		
	}
	
	public void setPendingPeerManager(PendingPeerManager pendingPeerManager) {
		if (this.pendingPeerManager == null) {
			this.pendingPeerManager = pendingPeerManager;
		}		
	}


	public void showError(String errorMessage) {
		showMessage("An error occured: " + errorMessage);
	}

	public void showMessage(String message) {
		System.out.println(message);
	}
}
