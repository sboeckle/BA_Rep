/**
 * 
 */
package de.htwg.net.test.peer;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author Ellen
 *
 */
public class ActivePeerManager {
	
	private UserDialog userDialog;
	private PendingPeerManager pendingPeerManager;
	
	private ArrayList<ActivePeer> listOfPeers = new ArrayList<ActivePeer>();

	public ActivePeerManager(UserDialog userDialog, PendingPeerManager pendingPeerManager) {
		this.userDialog = userDialog;
		this.pendingPeerManager = pendingPeerManager;
		this.userDialog.setActivePeerManager(this);
		pendingPeerManager.start(this);		
	}


	public void sendToAll(String message) {
		if (message != null) {
			Iterator<ActivePeer> iterator = listOfPeers.iterator();
			while(iterator.hasNext()) {
				iterator.next().sendMessage(message);
			}
		}		
	}
	
	public synchronized boolean isAlreadyConnected(String peerName, String address, int port) {
		if (peerName != null || address != null || port == 0) {
			Iterator<ActivePeer> iterator = listOfPeers.iterator(); 
			while (iterator.hasNext()) {
				if ((iterator.next()).getPeerName().equals(peerName) &&
					(iterator.next()).getAddress().equals(address) &&
					(iterator.next()).getPort() == port) {
					return true;
				}
			}
		}
		return false;
	}
	
	public synchronized void addActivePeer(String peerName, String address, int port, InputStream inputStream, OutputStream outputStream) {
		listOfPeers.add(new ActivePeer(peerName, address, port, userDialog, this, pendingPeerManager, inputStream, outputStream));
	}


	public void removeActivePeer(ActivePeer activePeer) {
		listOfPeers.remove(activePeer);		
	}

}
