package de.htwg.net.test.peer;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.Iterator;

public class PeerApp {
	
	private String peerName;
	private String address;
	private int port = 0;
	
	private ArrayList<PendingPeer> initialPeers;
	
	
	/**
	 * Method to initiate all resources for the peer application.
	 * 
	 * @param args command line arguments
	 */
	private void init(String[] args) {
		
		// read commandline args
		String error = parseCommandlineArgs(args);
		
		// display correct usage, if error occured
		if (error != null) {
			System.out.println(error);
			System.out.println("Correct usage example: Ellen [192.168.2.102:8205] 192.168.2.104:8206");
		}
		
		try {
			UserDialog userDialog = new UserDialog(peerName, address, port);
			
			PendingPeerManager pendingPeerManager = new PendingPeerManager(userDialog);
			if (initialPeers != null) {
				Iterator<PendingPeer> iterator = initialPeers.iterator();
				while (iterator.hasNext()) {
					pendingPeerManager.addNewPeer(iterator.next());
				}
			}	
			
			new ActivePeerManager(userDialog, pendingPeerManager);
			
			ServerSocket serverSocket = new ServerSocket(port);
			// loop for accepting new peer connections
			while (true) {
				pendingPeerManager.addNewPeer(serverSocket.accept());
			}			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	/**
	 * Method to parse commandline arguments.
	 * 
	 * @param args commandline arguments
	 * @return error description, null if no error occured
	 */
	private String parseCommandlineArgs(String[] args) {		
		// incorrect usage
		if ((args == null) || (args.length == 1)) {
			return "Not enough parameters.";
		}
		peerName = args[0].trim();
		if (peerName.length() == 0) {
			return "No peer name specified.";
		}
		// parse peer addresses
		for (int i = 1; i < args.length; i++) {
			String s = args[i];
			if (s.startsWith("[") && s.endsWith("]")) {
				
				String myAddress = s.substring(1, s.length() - 1);
				String[] myAddressSplitted = myAddress.split(":");
				String myIP = myAddressSplitted[0];
				int myPort = Integer.parseInt(myAddressSplitted[1]);
				
				address = myIP;
				port = myPort;
			} else {
				
				String[] peerAddressSplitted = s.split(":");
				String peerIP = peerAddressSplitted[0];
				int peerPort = Integer.parseInt(peerAddressSplitted[1]);
				
				if (initialPeers == null) {
					initialPeers = new ArrayList<PendingPeer>();
				}
				initialPeers.add(new PendingPeer(null, "?", peerIP, peerPort));
			}			
		}		
		return null;
	}

	
	/**
	 * Main method to start a Peer application.
	 * 
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		// start peer application
		new PeerApp().init(args);
	}
}
