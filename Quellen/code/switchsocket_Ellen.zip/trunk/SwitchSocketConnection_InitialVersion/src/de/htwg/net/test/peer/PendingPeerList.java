package de.htwg.net.test.peer;

import java.util.LinkedList;

public class PendingPeerList extends LinkedList<PendingPeer> {

	private static final long serialVersionUID = 1L;
	

	/* (non-Javadoc)
	 * @see java.util.LinkedList#add(java.lang.Object)
	 */
	@Override
	public synchronized boolean add(PendingPeer e) {
		// TODO Auto-generated method stub
		boolean returnValue = super.add(e);
		notifyAll();
		return returnValue;
	}
	
	public synchronized PendingPeer getNextPeer() {
		while (this.size() == 0) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				// TODO: DO NOTHING?
			}
		}
		PendingPeer nextPeer = this.getFirst();
		this.removeFirst();
		return nextPeer;
	}

}
