/**
 * 
 */
package de.htwg.net.test.peer;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * @author Ellen
 *
 */
public class ActivePeer extends Thread {

	private String peerName;
	private String address;
	private int port = 0;
	
	private UserDialog userDialog;
	private ActivePeerManager activePeerManager;
	private PendingPeerManager pendingPeerManager;
	
	private PeerReader peerReader;
	private PeerWriter peerWriter;
	

	public ActivePeer(String peerName, String address, int port, 
			UserDialog userDialog, ActivePeerManager activePeerManager, 
			PendingPeerManager pendingPeerManager, InputStream inputStream, OutputStream outputStream) {
		this.peerName = peerName;
		this.address = address;
		this.port = port;
		this.userDialog = userDialog;
		this.activePeerManager = activePeerManager;
		this.pendingPeerManager = pendingPeerManager;
		this.peerReader = new PeerReader(inputStream);
		this.peerWriter = new PeerWriter(outputStream);
		start();
	}

	
	public void run() {
		String message;
		while ((message = peerReader.readLine()) != null) {
			processMessage(message);
		}
		activePeerManager.removeActivePeer(this);
		userDialog.showMessage("Disconnect: " + peerName);
	}


	private void processMessage(String message) {
		message = message.trim();		
		if (message.length() == 0) {
			return;
		} else {
			userDialog.showMessage(peerName + ": " + message);
		}		
	}
	
	public void sendMessage(String message) {
		peerWriter.writeLine(message);
	}


	/**
	 * @return the peerName
	 */
	public String getPeerName() {
		return peerName;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @return the port
	 */
	public int getPort() {
		return port;
	}
}
