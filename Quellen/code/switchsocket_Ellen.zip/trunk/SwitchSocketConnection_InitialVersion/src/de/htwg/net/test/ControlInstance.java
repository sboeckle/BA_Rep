package de.htwg.net.test;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

public class ControlInstance implements Runnable {
	
	private TCPByteSender sender;
	private static final int[] sleepTimesInMillis = {	157, 312,  91, 203, 289, 330,  71, 643, 169, 802,
														994, 889, 760, 179, 621, 219, 682, 374, 656,   3, 
														492, 331, 411, 289, 781, 473,  10,  30, 942, 853  };
	
	
	public ControlInstance(TCPByteSender sender) {
		this.sender = sender;
	}


	@Override
	public void run() {
		int count = 0;
		while (true) {
			if (count == (sleepTimesInMillis.length - 1)) {
				count = 0;
			}
			int sleepTimeInMillis = sleepTimesInMillis[count++];
			System.out.println("SLEEP: " + sleepTimeInMillis);
			try {
				Thread.sleep(sleepTimeInMillis);
				System.out.println("SWITCH");
				Socket socket = new Socket("localhost", 8205);
				sender.getSocket().switchSocket(socket);
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				break;
			}
		}
		
	}
}
