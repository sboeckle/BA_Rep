package de.htwg.net.test.peer;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class PeerWriter extends Thread {

	private ArrayList<String> messages;
	private BufferedWriter writer;
	
	
	public PeerWriter(OutputStream outputStream) {
		messages = new ArrayList<String>();
		writer = new BufferedWriter(new OutputStreamWriter(outputStream));
		start();
	}
	
	public void run() {
		while (true) {
			try {
				writer.write(getLine());
				writer.newLine();
				writer.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
	}

	private synchronized String getLine() {
		while (messages.isEmpty()) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		String message = messages.get(0);
		messages.remove(0);
		return message;
	}

	public synchronized void writeLine(String line) {
		messages.add(line);
		notifyAll();
	}

}
