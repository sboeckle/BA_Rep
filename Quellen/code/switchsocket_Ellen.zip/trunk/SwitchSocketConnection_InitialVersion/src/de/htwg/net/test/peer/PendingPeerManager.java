/**
 * 
 */
package de.htwg.net.test.peer;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * @author Ellen
 *
 */
public class PendingPeerManager extends Thread {
	
	private UserDialog userDialog;
//	private PendingPeerLinkedList pendingPeers = new PendingPeerLinkedList();
	private PendingPeerList pendingPeers = new PendingPeerList();
	private ActivePeerManager activePeerManager = null;

	public PendingPeerManager(UserDialog userDialog) {
		this.userDialog = userDialog;
		userDialog.setPendingPeerManager(this);
	}

	public void addNewPeer(PendingPeer peer) {
		// TODO: maybe problem with multiple ip adresses
		if(peer.getSocket() == null) {
			try {
				Socket socket = new Socket(peer.getAddress(), peer.getPort());
				peer.setSocket(socket);
				pendingPeers.add(peer);
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		}			
	}

	public void addNewPeer(Socket socket) {
		pendingPeers.add(new PendingPeer(socket, "X", socket.getRemoteSocketAddress().toString(), socket.getPort()));
	}
		
	public void start(ActivePeerManager activePeerManager) {
		this.activePeerManager = activePeerManager;
		start();
	}
	
	public void run() {
		// TODO: possible without extra linked list?
		while (true) {		
			
//			handleNewPeerClient(pendingPeers.next());
			handleNewPeerClient(pendingPeers.getNextPeer());
		}
	}

	private void handleNewPeerClient(PendingPeer peer) {
		String peerName = peer.getPeerName();
		String address =  peer.getAddress();
		int port = peer.getPort();
		if(activePeerManager.isAlreadyConnected(peerName, address, port)) {
			return;
		}
		Socket socket = peer.getSocket();
	
		InputStream inputStream = null;
		OutputStream outputStream = null;
		try {
			inputStream = socket.getInputStream();
			outputStream = socket.getOutputStream();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			userDialog.showError("Getting streams from socket failed.");
		}	
		activePeerManager.addActivePeer(peerName, address, port, inputStream, outputStream);
		userDialog.showMessage("Connection from: " + peerName + " " + address);
	}

}
