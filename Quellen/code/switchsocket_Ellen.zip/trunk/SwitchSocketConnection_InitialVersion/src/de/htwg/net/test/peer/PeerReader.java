package de.htwg.net.test.peer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class PeerReader extends Thread {
	
	private ArrayList<String> messages;
	private BufferedReader reader;
	

	/**
	 * @param inputStream
	 */
	public PeerReader(InputStream inputStream) {
		messages = new ArrayList<String>();
		reader = new BufferedReader(new InputStreamReader(inputStream));
		start();
	}

	
	/* (non-Javadoc)
	 * @see java.lang.Thread#run()
	 */
	public void run() {
		try {
			String line;
			while (null != (line = reader.readLine())) {
				addToMessages(line);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * @return
	 */
	public synchronized String readLine() {
		while (messages.isEmpty()) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		String message = messages.get(0);
		messages.remove(0);
		return message;
	}

	/**
	 * @param line
	 */
	private synchronized void addToMessages(String line) {
		messages.add(line);
		notifyAll();
	}

}
