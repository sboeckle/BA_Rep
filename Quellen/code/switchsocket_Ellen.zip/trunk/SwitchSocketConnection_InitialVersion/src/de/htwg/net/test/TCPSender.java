package de.htwg.net.test;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import de.htwg.net.SwitchableSocket;

public class TCPSender {

	private SwitchableSocket socket;
	private ObjectOutputStream out;
	private ObjectInputStream in;
	
	public TCPSender() {
		try {
			socket = new SwitchableSocket(new Socket("localhost", 8205));
			out = new ObjectOutputStream(socket.getOutputStream());
			in = new ObjectInputStream(socket.getInputStream());
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void sendMessage(String message) {
		try {
			out.writeObject(message);
			out.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public SwitchableSocket getSocket() {
		return socket;
	}

}
