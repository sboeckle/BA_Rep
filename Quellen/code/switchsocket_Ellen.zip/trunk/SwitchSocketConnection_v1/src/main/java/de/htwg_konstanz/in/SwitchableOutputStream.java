package de.htwg_konstanz.in;

import java.io.IOException;
import java.io.OutputStream;

/**
 * The class SwitchableOutputStream is a wrapper class for an OutputStream object.
 * It offers the additional functionality to switch the underlying OutputStream.
 * All methods in SwitchableOutputStream have to be synchronized so that no operation 
 * can be made on the old stream which was already switched to a new one.
 * 
 * @author Ellen Wieland
 * 
 */
public class SwitchableOutputStream extends OutputStream {

	/**
	 * the underlying OutputStream.
	 */
	private volatile OutputStream outputStream;
	
	
	/**
	 * Constructor to create new SwitchableOutputStream from normal OutputStream.
	 * 
	 * @param outputStream normal OutputStream to be wrapped.
	 */
	public SwitchableOutputStream(OutputStream outputStream) {
		this.outputStream = outputStream;
	}

	/**
	 * Switches the old underlying OutputStream after flushing to the new one supplied.
	 * 
	 * @param outputStream new OutputStream to switch to.
	 * @throws IOException is thrown when an exception occurs in outputStream.flush().
	 */
	public synchronized void switchOutputStream(OutputStream outputStream) throws IOException {
		this.outputStream.flush();
		this.outputStream = outputStream;
	}

	// delegate work to internal output stream

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.io.OutputStream#close()
	 */
	@Override
	public synchronized void close() throws IOException {
		outputStream.close();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.io.OutputStream#flush()
	 */
	@Override
	public synchronized void flush() throws IOException {
		outputStream.flush();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.io.OutputStream#write(byte[], int, int)
	 */
	@Override
	public synchronized void write(byte[] b, int off, int len) throws IOException {
		outputStream.write(b, off, len);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.io.OutputStream#write(byte[])
	 */
	@Override
	public synchronized void write(byte[] b) throws IOException {
		outputStream.write(b);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.io.OutputStream#write(int)
	 */
	@Override
	public synchronized void write(int b) throws IOException {
		outputStream.write(b);
	}

}
