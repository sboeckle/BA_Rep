package de.htwg_konstanz.in;

import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * The class SwitchableInputStream is a wrapper class for an InputStream object.
 * It offers the additional functionality to switch the underlying InputStream.
 * 
 * @author Ellen Wieland
 * 
 */
public class SwitchableInputStream extends InputStream {

	/**
	 * the underlying InputStream.
	 */
	private InputStream inputStream;
	/**
	 * queue for new InputStreams to switch to.
	 */
	private BlockingQueue<InputStream> newInputStreams;
	/**
	 * flag to signal that the underlying old InputStream should be 
	 * switched to a new one when available.
	 */
	private volatile boolean registeredForSwitch;

	
	/**
	 * Constructor to create new SwitchableInputStream from normal InputStream.
	 * 
	 * @param inputStream normal InputStream to be wrapped.
	 */
	public SwitchableInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
		this.newInputStreams = new LinkedBlockingQueue<InputStream>();
	}

	/**
	 * Sets flag registeredForSwitch to true.
	 */
	public void registerForSwitch() {
		this.registeredForSwitch = true;
	}

	/**
	 * Adds new InputStream to the queue newInputStreams. 
	 * 
	 * @param inputStream new InputStream to switch to.
	 */
	public void switchInputStream(InputStream inputStream) {
		this.newInputStreams.add(inputStream);
	}

	// delegate work to internal input stream

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.io.InputStream#available()
	 */
	@Override
	public int available() throws IOException {
		return inputStream.available();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.io.InputStream#close()
	 */
	@Override
	public void close() throws IOException {
		inputStream.close();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.io.InputStream#mark(int)
	 */
	@Override
	public synchronized void mark(int readlimit) {
		inputStream.mark(readlimit);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.io.InputStream#markSupported()
	 */
	@Override
	public boolean markSupported() {
		return inputStream.markSupported();
	}

	
	/**
	 * In addition to the functionality of read(byte[] b, int off, int len) from InputStream, 
	 * this method checks with every read operation if the underlying InputStream should be switched
	 * to a new connection.
	 * 
	 * @see java.io.InputStream#read(byte[], int, int)
	 */
	@Override
	public int read(byte[] b, int off, int len) throws IOException {
		int data = 0;
		if ((data = inputStream.read(b, off, len)) == -1) {
			// test if EOF was caused because other side wants to switch the connection
			if (registeredForSwitch) {
				try {
					inputStream = newInputStreams.take();
					registeredForSwitch = false;
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				return this.read(b, off, len);
			// not caused by switch connection
			} else {
				return -1;
			}
		} else {
			return data;
		}
	}

	/**
	 * In addition to the functionality of read(byte[] b) from InputStream, 
	 * this method checks with every read operation if the underlying InputStream should be switched
	 * to a new connection.
	 * 
	 * @see java.io.InputStream#read(byte[], int, int)
	 */
	@Override
	public int read(byte[] b) throws IOException {
		int data = 0;
		if ((data = inputStream.read(b)) == -1) {
			// test if EOF was caused because other side wants to switch the connection
			if (registeredForSwitch) {
				try {
					inputStream = newInputStreams.take();
					registeredForSwitch = false;
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				return this.read(b);
			// not caused by switch connection
			} else {
				return -1;
			}
		} else {
			return data;
		}
	}

	/**
	 * In addition to the functionality of read() from InputStream, this method checks 
	 * with every read operation if the underlying InputStream should be switched
	 * to a new connection.
	 * 
	 * @see java.io.InputStream#read(byte[], int, int)
	 */
	@Override
	public int read() throws IOException {
		int data = 0;
		if ((data = inputStream.read()) == -1) {
			// test if EOF was caused because other side wants to switch the connection
			if (registeredForSwitch) {
				try {
					inputStream = newInputStreams.take();
					registeredForSwitch = false;
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				return this.read();
			// not caused by switch connection
			} else {
				return -1;
			}
		} else {
			return data;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.io.InputStream#reset()
	 */
	@Override
	public synchronized void reset() throws IOException {
		inputStream.reset();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.io.InputStream#skip(long)
	 */
	@Override
	public long skip(long n) throws IOException {
		return inputStream.skip(n);
	}
}
