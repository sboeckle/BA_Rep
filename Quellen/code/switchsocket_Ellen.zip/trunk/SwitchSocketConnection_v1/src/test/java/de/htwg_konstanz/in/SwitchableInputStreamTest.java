package de.htwg_konstanz.in;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.BlockingQueue;

import org.junit.Before;
import org.junit.Test;

/**
 * Unit Test for the SwitchableInputStream class.
 * 
 * @author Ellen Wieland
 *
 */
public class SwitchableInputStreamTest {

	/**
	 * Test string to create InputStream object of.
	 */
	private static final String TEST_STRING = "Test string to create input stream from.";
	/**
	 * SwitchableInputStream object to test.
	 */
	private SwitchableInputStream switchableInputStream;

	/**
	 * Creates new SwitchableInputStream object from InputStream of the test string before every test.
	 */
	@Before
	public void setUp() {
		InputStream inputStream = new ByteArrayInputStream(TEST_STRING.getBytes());
		switchableInputStream = new SwitchableInputStream(inputStream);
	}

	/**
	 * Tests if flag registeredForSwitch is set correctly in the registerForSwitch() method.
	 */
	@Test
	public void testRegisterForSwitch() {
		// before calling the registerForSwitch() method the field has to be false
		Boolean registeredForSwitch = (Boolean) PrivateAccessor.getPrivateField(switchableInputStream, "registeredForSwitch");
		assertFalse("registeredForSwitch should be false", registeredForSwitch);
		// call the method to test
		switchableInputStream.registerForSwitch();
		// after calling the registerForSwitch() method the field has to be true
		registeredForSwitch = (Boolean) PrivateAccessor.getPrivateField(switchableInputStream, "registeredForSwitch");
		assertTrue("registeredForSwitch should be true", registeredForSwitch);
	}

	
	/**
	 * Tests if new InputStream is added to queue when switchInputStream() method is called.
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testSwitchInputStream() {
		// get reference of queue
		BlockingQueue<InputStream> newInputStreams = (BlockingQueue<InputStream>) PrivateAccessor.getPrivateField(switchableInputStream, "newInputStreams");
		// before switch queue has to be empty
		assertTrue(newInputStreams.isEmpty());
		// switch the underlying input stream
		String secondTestString = "Second test string to create input stream from";
		InputStream newInputStream = new ByteArrayInputStream(secondTestString.getBytes());
		switchableInputStream.switchInputStream(newInputStream);
		// after switch queue has to have elements
		assertFalse("There should be an entry in the queue", newInputStreams.isEmpty());
	}

	/**
	 * Tests correct functionality of read(b, off, len).
	 */
	@Test
	public void testReadBOffLen() {
		// create resources to save the data read
		byte[] b = new byte[1];
		int dataRead = -1;
		int off = 0;
		int len = 1;
		// try to read from switchableInputStream
		try {
			dataRead = switchableInputStream.read(b, off, len);
		} catch (IOException e) {
			fail("The following exception occured: " + e.getMessage());
		}
		for (int i = 0; i < b.length; i++) {
			System.out.print(b[i] + " ");
		}
		System.out.println();
		System.out.println(dataRead);
		// assert that there was data read from the stream and that data equals the data from the test string
		assertFalse("Byte array should not be empty", b.length == 0);
		assertFalse("dataRead should not be -1", dataRead == -1);
		assertArrayEquals("Data read has to be the same as the data of the test string", TEST_STRING.substring(off, len).getBytes(), b);
	}

	/**
	 * Tests correct functionality of read(b).
	 */
	@Test
	public void testReadB() {
		// create resources to save the data read
		byte[] b = new byte[TEST_STRING.getBytes().length];
		int dataRead = -1;
		// try to read from switchableInputStream
		try {
			dataRead = switchableInputStream.read(b);
		} catch (IOException e) {
			fail("The following exception occured: " + e.getMessage());
		}
		for (int i = 0; i < b.length; i++) {
			System.out.print(b[i] + " ");
		}
		System.out.println();
		System.out.println(dataRead);
		// assert that there was data read from the stream and that data equals the data from the test string
		assertFalse("Byte array should not be empty", b.length == 0);
		assertFalse("dataRead should not be -1", dataRead == -1);
		assertArrayEquals("Data read has to be the same as the data of the test string", TEST_STRING.getBytes(), b);
	}

	/**
	 * Tests correct functionality of read().
	 */
	@Test
	public void testRead() {
		// create resources to save the data read
		int dataRead = -1;
		// try to read from switchableInputStream
		try {
			dataRead = switchableInputStream.read();
		} catch (IOException e) {
			fail("The following exception occured: " + e.getMessage());
		}
		System.out.println(dataRead);
		// assert that there was data read from the stream and that data equals the data from the test string
		assertFalse("dataRead should not be -1", dataRead == -1);
	}

}
