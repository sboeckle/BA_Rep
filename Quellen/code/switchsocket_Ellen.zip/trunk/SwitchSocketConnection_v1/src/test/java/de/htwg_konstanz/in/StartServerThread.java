package de.htwg_konstanz.in;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Class to start an instance of the Server class in an own Thread.
 * 
 * @author Ellen Wieland
 *
 */
public class StartServerThread implements Runnable {
	
	/**
	 * port to listen to.
	 */
	private static final int SERVER_PORT = 8205;

	/** 
	 * Starts instance of the Server class and creates a ServerSocket to listen at SERVER_PORT.
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		try {
			ServerSocket serverSocket = new ServerSocket(SERVER_PORT);			
			System.out.println("TCPServer waiting for messages..");
			
			Server server = new Server(serverSocket.accept());
			Thread thread = new Thread(server);
			thread.start();
			
			while (true) {
				// switch socket connection when a new client connects
				Socket newSocket = serverSocket.accept();
				System.out.println("SWITCH");
				server.getSwitchableSocket().switchSocket(newSocket);
			}			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}
