/**
 * 
 */
package de.htwg_konstanz.in;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;

/**
 * Client part of test system.
 * 
 * @author Ellen Wieland
 *
 */
public class Client {
	
	/**
	 * remote address.
	 */
	private static final String SERVER_ADDRESS = "localhost";
	/**
	 * remote port.
	 */
	private static final int SERVER_PORT = 8205;
	
	/**
	 * wrapped socket connection.
	 */
	private SwitchableSocket switchableSocket;
	/**
	 * InputStream from socket connection.
	 */
	private InputStream in;
	/**
	 * OutputStream from socket connection.
	 */
	private OutputStream out;
	
	
	/**
	 * Constructor to create new Client for test system.
	 */
	public Client() {
		try {
			switchableSocket = new SwitchableSocket(new Socket(SERVER_ADDRESS, SERVER_PORT));
			out = switchableSocket.getOutputStream();
			in = switchableSocket.getInputStream();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Sends message to an echo server and waits until it gets the same amount of data back.
	 * 
	 * @param message test message to be sent.
	 * @return answer from echo server.
	 * @throws SocketException thrown when -1 is read.
	 * @throws IOException thrown when a socket operation fails.
	 */
	public String sendMessage(String message) throws SocketException, IOException {
		try {
			out.write(message.getBytes(), 0, message.getBytes().length);
			out.flush();
			
			System.out.println("Sent: " + message);
		} catch (IOException e) {
			e.printStackTrace();
		}
		// Receive the same string back from the server
		byte[] buffer = new byte[message.getBytes().length];
		
	    int totalBytesRcvd = 0;  // Total bytes received so far
	    int bytesRcvd;           // Bytes received in last read
	    while (totalBytesRcvd < message.getBytes().length) {
	      if ((bytesRcvd = in.read(buffer, totalBytesRcvd, message.getBytes().length - totalBytesRcvd)) == -1)
	        throw new SocketException("Connection closed prematurely");
	      totalBytesRcvd += bytesRcvd;
	    }  // data array is full

	    System.out.println("Received: " + new String(buffer));
	    return new String(buffer);
	}
	
	/**
	 * Getter for the wrapped socket connection.
	 * 
	 * @return wrapped socket object.
	 */
	public SwitchableSocket getSocket() {
		return switchableSocket;
	}

}
