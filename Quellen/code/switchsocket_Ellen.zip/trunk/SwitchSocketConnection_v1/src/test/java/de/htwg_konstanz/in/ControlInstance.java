package de.htwg_konstanz.in;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * Superordinate instance to initialize switching of connection.
 * 
 * @author Ellen Wieland
 *
 */
public class ControlInstance implements Runnable {
	
	/**
	 * Client which socket connection to server should be switched.
	 */
	private Client client;
	
	/**
	 * local address.
	 */
	private static final String SERVER_ADDRESS = "localhost";
	/**
	 * local port.
	 */
	private static final int SERVER_PORT = 8205;
	
	/**
	 * array of randomly created numbers used to wait between attempts to switch connection.
	 */
	private static final int[] SLEEP_TIMES_IN_MILLIS = { 20,   5, 157, 312,  91, 203, 289, 330,  71, 169, 
														994, 889, 760, 179, 621, 219, 682, 374, 656,   3, 
														492, 331, 411, 289, 781, 473,  10,  30, 942, 853  };
	
	
	/**
	 * Constructor to create new ControlInstance for corresponding client.
	 * 
	 * @param client corresponding client on which connection to the server should be switched.
	 */
	public ControlInstance(Client client) {
		this.client = client;
	}


	/**
	 * Sleep according to value from SLEEP_TIMES_IN_MILLIS array and then try to switch connection.
	 * Can be stopped by interrupting the thread.
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		int count = 0;
		while (true) {
			if (count == (SLEEP_TIMES_IN_MILLIS.length - 1)) {
				count = 0;
			}
			int sleepTimeInMillis = SLEEP_TIMES_IN_MILLIS[count++];
			System.out.println("SLEEP: " + sleepTimeInMillis);
			try {
				Thread.sleep(sleepTimeInMillis);
				System.out.println("SWITCH");
				Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
				client.getSocket().switchSocket(socket);
			} catch (UnknownHostException e) {
				e.printStackTrace();			
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				// end of test
				break;
			}
		}
		
	}
}
