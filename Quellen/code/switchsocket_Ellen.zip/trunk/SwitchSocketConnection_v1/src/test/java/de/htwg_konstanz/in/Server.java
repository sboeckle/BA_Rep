/**
 * 
 */
package de.htwg_konstanz.in;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * Server part of the test system.
 * 
 * @author Ellen Wieland
 *
 */
public class Server implements Runnable {

	/**
	 * local port to listen to.
	 */
	private static final int SERVER_PORT = 8205;
	/**
	 * size of buffer for receiving data.
	 */
	private static final int BUFFER_SIZE = 32;
	
	/**
	 * wrapped socket connection.
	 */
	private SwitchableSocket switchableSocket;
	/**
	 * InputStream from socket connection.
	 */
	private InputStream in;
	/**
	 * OutputStream from socket connection.
	 */
	private OutputStream out;
	
		
	/**
	 * Constructor to create new instance of Server.
	 * 
	 * @param socket accepted connection from client.
	 */
	public Server(Socket socket) {
		try {
			switchableSocket = new SwitchableSocket(socket);
			out = switchableSocket.getOutputStream();
			in = switchableSocket.getInputStream();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Getter for the wrapped socket connection.
	 * 
	 * @return wrapped socket object.
	 */
	public SwitchableSocket getSwitchableSocket() {
		return switchableSocket;
	}

	/**
	 * In this method data from client is received and echoed back until -1 is read.
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {		
		try {
			byte[] buffer = new byte[BUFFER_SIZE];
			int recvMsgSize;
			while ((recvMsgSize = in.read(buffer)) != -1) {				
				String message = new String(buffer).trim();
				System.out.println(message.substring(0, recvMsgSize));
				out.write(buffer, 0, recvMsgSize);
				out.flush();
			}
			System.out.println("Received EOF -> end server");
			// end of test
			System.exit(0);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Main method to start Server on a different machine than the client.
	 * 
	 * @param args command line arguments.
	 */
	public static void main(String[] args) {		
		try {
			ServerSocket serverSocket = new ServerSocket(SERVER_PORT);			
			System.out.println("TCPServer waiting for messages..");			
			Server server = new Server(serverSocket.accept());
			Thread thread = new Thread(server);
			thread.start();			
			while (true) {
				// switch socket connection when a new client connects
				Socket newSocket = serverSocket.accept();
				System.out.println("SWITCH");
				server.switchableSocket.switchSocket(newSocket);
			}			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
