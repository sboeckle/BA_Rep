package de.htwg_konstanz.in;

import java.lang.reflect.Field;

import org.junit.Assert;

/**
 * Class to provide access to private members in classes.
 * 
 * After "Subverting Java Access Protection for Unit Testing".
 * (http://onjava.com/pub/a/onjava/2003/11/12/reflection.html?page=2)
 */
public class PrivateAccessor {

	/**
	 * Tries to get the private field with the name supplied.
	 * 
	 * @param object Object to get field from.
	 * @param fieldName name of field to try to access.
	 * @return private field, null if field was not found.
	 */
	public static Object getPrivateField(Object object, String fieldName) {
		// check we have valid arguments
		Assert.assertNotNull(object);
		Assert.assertNotNull(fieldName);
		// find the private field
		final Field fields[] = object.getClass().getDeclaredFields();
		for (int i = 0; i < fields.length; ++i) {
			if (fieldName.equals(fields[i].getName())) {
				try {
					fields[i].setAccessible(true);
					return fields[i].get(object);
				} catch (IllegalAccessException ex) {
					Assert.fail("IllegalAccessException accessing " + fieldName);
				}
			}
		}
		Assert.fail("Field '" + fieldName + "' not found");
		return null;
	}
}