package de.htwg_konstanz.in;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.fail;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.junit.Before;
import org.junit.Test;

/**
 * Unit Test for the SwitchableOutputStream class.
 * 
 * @author Ellen Wieland
 *
 */
public class SwitchableOutputStreamTest {

	/**
	 * SwitchableOutputStream object to test.
	 */
	private SwitchableOutputStream switchableOutputStream;

	/**
	 * Creates new SwitchableOutputStream object from an OutputStream object before every test.
	 */
	@Before
	public void setUp() {
		OutputStream outputStream = new ByteArrayOutputStream();
		switchableOutputStream = new SwitchableOutputStream(outputStream);
	}

	/**
	 * Tests that OutputStream object is changed after calling switchOutputStream().
	 */
	@Test
	public void testSwitchOutputStream() {
		OutputStream oldOutputStream = (OutputStream) PrivateAccessor.getPrivateField(switchableOutputStream, "outputStream");
		try {
			OutputStream newOutputStream = new ByteArrayOutputStream();
			switchableOutputStream.switchOutputStream(newOutputStream);
		} catch (IOException e) {
			fail("The following exception occured: " + e.getMessage());
		}
		OutputStream newOutputStream = (OutputStream) PrivateAccessor.getPrivateField(switchableOutputStream, "outputStream");
		// old and new stream are not equal
		assertFalse("Old and new output stream should be different", oldOutputStream.equals(newOutputStream));
	}
}
